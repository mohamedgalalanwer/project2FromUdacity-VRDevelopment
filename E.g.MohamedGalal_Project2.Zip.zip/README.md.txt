MyName Is :MohamedGalalAnwer

i'd like when arrange the models
and do the anmition 

but light i can't understand it 

3 hours


 challenging time 
when t use the Lights in scene and work the steps 
i do the steps correct but when bake the Light 
not given sweet shape

GoogleVR Unity SDK (v 1.0.3)
VRND Course 2 Starter Project (version 3)